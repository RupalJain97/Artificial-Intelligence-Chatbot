// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';
 
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {Card, Suggestion} = require('dialogflow-fulfillment');
const admin = require('firebase-admin'); 
const nodemailer=require('nodemailer');
const handlebars=require('handlebars');

process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements

admin.initializeApp(functions.config().firebase);
const db = admin.firestore();
admin.firestore().settings( { timestampsInSnapshots: true });

exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
 
  function welcome(agent) {
    agent.add(`Welcome to my agent!`);
  }
 
  function fallback(agent) {
    agent.add(`I didn't understand`);
    agent.add(`I'm sorry, can you try again?`);
  }

  function courses(agent){
		var no=agent.parameters.number;
		if(no===""){
			no=5;
		}
		if (agent.parameters.streams=='medical'){
			const dialogflowAgentDoc = db.collection('medicalCourses');
			return dialogflowAgentDoc.where("rank","<=",no).get()
			.then(doc => {
				doc.forEach(function(q){
					agent.add(q.data().course);
				});
				return Promise.resolve('Read complete');
			}).catch(() => {
				agent.add('Error reading entry from the Firestore database.');
				agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
			});
		}
		if (agent.parameters.streams=='non medical' || agent.parameters.streams=='nonmedical'){
			const dialogflowAgentDoc = db.collection('nonmedicalCourses');
			return dialogflowAgentDoc.where("rank","<=",no).get()
			.then(doc => {
				doc.forEach(function(q){
					agent.add(q.data().course);
				});
				return Promise.resolve('Read complete');
			}).catch(() => {
				agent.add('Error reading entry from the Firestore database.');
				agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
			});
		}
		if (agent.parameters.streams=='commerce'){
			const dialogflowAgentDo = db.collection('commerceCourses');
			return dialogflowAgentDo.where("rank","<=",no).get()
			.then(doc => {
				doc.forEach(function(q){
					agent.add(q.data().course);
				});
				return Promise.resolve('Read complete');
			}).catch(() => {
				agent.add('Error reading entry from the Firestore database.');
				agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
			});
		}
		if (agent.parameters.streams=='humanity'){
			const dialogflowAgent = db.collection('artsCourses');
			return dialogflowAgent.where("rank","<=",no).get()
			.then(doc => {
				doc.forEach(function(q){
					agent.add(q.data().course);
				});
				return Promise.resolve('Read complete');
			}).catch(() => {
				agent.add('Error reading entry from the Firestore database.');
				agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
			});
		}
	}
  
  function occupation(agent){
		var no=agent.parameters.number;
		if(no===""){
			no=5;
		}
		if (agent.parameters.streams=='medical'){
			const dialogflowAgentDoc = db.collection('medicalOcc');
			return dialogflowAgentDoc.where("rank","<=",no).get()
			.then(doc => {
				doc.forEach(function(q){
					agent.add(q.data().field);
				});
				return Promise.resolve('Read complete');
			}).catch(() => {
				agent.add('Error reading entry from the Firestore database.');
				agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
			});
		}
		if (agent.parameters.streams=='non medical' || agent.parameters.streams=='nonmedical'){
			const dialogflowAgentDoc = db.collection('nonmedicalOcc');
			return dialogflowAgentDoc.where("rank","<=",no).get()
			.then(doc => {
				doc.forEach(function(q){
					agent.add(q.data().field);
				});
				return Promise.resolve('Read complete');
			}).catch(() => {
				agent.add('Error reading entry from the Firestore database.');
				agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
			});
		}
		if (agent.parameters.streams=='commerce'){
			const dialogflowAgentDo = db.collection('commerceOcc');
			return dialogflowAgentDo.where("rank","<=",no).get()
			.then(doc => {
				doc.forEach(function(q){
					agent.add(q.data().field);
				});
				return Promise.resolve('Read complete');
			}).catch(() => {
				agent.add('Error reading entry from the Firestore database.');
				agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
			});
		}
		if (agent.parameters.streams=='humanity'){
		const dialogflowAgent = db.collection('artsOcc');
		return dialogflowAgent.where("rank","<=",no).get()
		.then(doc => {
			doc.forEach(function(q){
				agent.add(q.data().field);
			});
			return Promise.resolve('Read complete');
		}).catch(() => {
			agent.add('Error reading entry from the Firestore database.');
			agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
		});
		}
	}
  function colleges(agent){
		var no=agent.parameters.number;
		if(no===""){
			no=5;
		}
		if(agent.parameters.streams =="medical"){   
			const dialogflowAgentDoc = db.collection('medical');
			return dialogflowAgentDoc.where("rank","<=",no).get()
			.then(doc => {
				doc.forEach(function(q){
					agent.add(q.data().college);
				});
				return Promise.resolve('Read complete');
			}).catch(() => {
				agent.add('Error reading entry from the Firestore database.');
				agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
			});
		}
		if(agent.parameters.streams=='non medical' || agent.parameters.streams=='nonmedical'){   
			const dialogflowAgentDo = db.collection('nonmedical');
			return dialogflowAgentDo.where("rank","<=",no).get()
			.then(doc => {
				doc.forEach(function(q){
					agent.add(q.data().college);
				});
				return Promise.resolve('Read complete');
			}).catch(() => {
				agent.add('Error reading entry from the Firestore database.');
				agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
			});
		}
		if(agent.parameters.streams =="humanity"){   
			const dialogflowAgentD = db.collection('arts');
			return dialogflowAgentD.where("rank","<=",no).get()
			.then(doc => {
				doc.forEach(function(q){
					agent.add(q.data().college);
				});
				return Promise.resolve('Read complete');
			}).catch(() => {
				agent.add('Error reading entry from the Firestore database.');
				agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
			});
		}
		
		if(agent.parameters.streams =="commerce"){   
			const dialogflowAgent = db.collection('commerce');
			return dialogflowAgent.where("rank","<=",no).get()
			.then(doc => {
				doc.forEach(function(q){
					agent.add(q.data().college);
				});
				return Promise.resolve('Read complete');
			}).catch(() => {
				agent.add('Error reading entry from the Firestore database.');
				agent.add('Please add a entry to the database first by saying, "Write <your phrase> to the database"');
			});
		}
		
    }
 
	function details(agent){
		var time=agent.parameters.time;
		var date=agent.parameters.date;
		const dialogflowAgentRef = db.collection('dialogflow').doc('agent');
		return db.runTransaction(t => {
			t.set(dialogflowAgentRef, { time:time, date: date });
			return Promise.resolve('Write complete');
		}).then(doc => {
		console.log(`Wrote  to the Firestore database.`);
		}).catch(err => {
		console.log(`Error writing to Firestore: ${err}`);
		//agent.add(`Failed to write  to the Firestore database.`);
		});
	}
  
  
	function counsellor(agent){
		var id=agent.parameters.email;
      	console.log("email: " , id);
		var transporter = nodemailer.createTransport({
			service: "gmail", // hostname
			auth: {
				user: "student.careerguide123@gmail.com",
				pass: "careerguide123"
			},
		});
		var time1;
		var date1;
		//reading data
		const dialogflowAgent = db.collection('dialogflow');
		dialogflowAgent.get()
		.then(doc => {
			doc.forEach(function(q){
              	//console.log("date-time: ", q.data());
				time1=q.data().time;
				date1=q.data().date;
				
				var d = date1.slice(0,10);
				var t=time1.slice(11,19);
				//console.log("Final time: ", t);
              	//console.log("Final date: ", d);
              
				var text='Hello, <br><br>Your appointment is scheduled with our  counsellor  at<b> {{time}} hours  on {{day}}.</b> <br><br> Thanks and Regards,<br> Career Guide';
				var template = handlebars.compile(text);
				var replacements = {
					"time":t,
					"day":d
				};
				var htmlToSend = template(replacements);
				var mailOptions = {
					from:'student.guidecareer@gmail.com',
					to: id,
					subject: 'Appointment Confirmation for Counselling',
					html:htmlToSend                                
				};
              	console.log("Mail details: ", mailOptions);
				transporter.sendMail(mailOptions, function (error, info) {
					if (error) {
						console.log(error);
					} else {
						console.log('Email sent: ' + info.response);
					}
				});
    
			//braces
			});
			return Promise.resolve('Read complete');
		}).catch(() => {
			console.log('Error reading entry from the Firestore database.');
		});
	}

  // Run the proper function handler based on the matched Dialogflow intent name
  let intentMap = new Map();
  intentMap.set('Default Welcome Intent', welcome);
  intentMap.set('Default Fallback Intent', fallback);
  intentMap.set('occupation', occupation);
  intentMap.set('colleges', colleges);
  intentMap.set('courses',courses);
  intentMap.set('counsellor - custom - yes - custom',counsellor);
  intentMap.set('counsellor - custom',details);
  agent.handleRequest(intentMap);
});
